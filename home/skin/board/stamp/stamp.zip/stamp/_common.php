<?
$g5_path = "../../..";
include_once("$g5_path/common.php");
?>